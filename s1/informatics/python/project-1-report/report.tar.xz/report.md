Implementacja algorytmu sortowania pozycyjnego (Radix Sort) dla liczb całkowitych i zmiennoprzecinkowych.

## Ogólny opis algorytmu Radix Sort

<img src="howard.jpg" alt="Harold H. Seward" style="float: right; margin-left: 15px; margin-bottom: 15px; max-width: 40%;">

### Historia

Radix Sort to niestandardowy algorytm sortowania, co oznacza, że nie opiera się na porównywaniu elementów. Jego koncepcja istniała już w maszynach do sortowania kart perforowanych na początku XX wieku. Współczesna wersja algorytmu, często bazująca na sortowaniu przez zliczanie (Counting Sort) lub sortowaniu kubełkowym (Bucket Sort) dla każdej pozycji cyfry, została opracowana przez Harolda H. Sewarda w 1954 roku.

### Działanie

Algorytm sortuje liczby poprzez grupowanie ich według pojedynczych cyfr, począwszy od najmniej znaczącej cyfry (LSD - Least Significant Digit) lub od najbardziej znaczącej cyfry (MSD - Most Significant Digit). Najczęściej używana jest wersja LSD, która jest stabilna i prostsza w implementacji dla liczb całkowitych o stałej długości lub ograniczonej maksymalnej wartości.

W wersji LSD Radix Sort (użytej w tej implementacji):

1. Znajdujemy maksymalną wartość w tablicy, aby określić liczbę cyfr.
2. Tworzymy 10 "kubełków" (ang. buckets, dlatego bucket sort) dla każdej cyfry od 0 do 9.
3. Przechodzimy przez tablicę wejściową, umieszczając każdy element w odpowiednim kubełku, bazując na wartości aktualnie rozpatrywanej cyfry (zaczynając od najmniej znaczącej).
4. Zbieramy elementy z kubełków w kolejności od 0 do 9, przepisując je z powrotem do tablicy wejściowej.
5. Powtarzamy kroki 3 i 4 dla każdej kolejnej cyfry (dziesiątek, setek, itd.), aż do najbardziej znaczącej cyfry maksymalnej wartości.

Stabilność algorytmu sortującego użytego w kroku 3 (np. Counting Sort lub proste wstawianie do kubełków i odczyt w kolejności) jest kluczowa, aby Radix Sort działał poprawnie w wersji LSD.

### Typy Radix Sort

* **LSD (Least Significant Digit) Radix Sort:** Sortowanie rozpoczyna się od najmniej znaczącej cyfry. Wymaga stabilnego pod-algorytmu sortującego. Stosowany głównie do liczb całkowitych.
* **MSD (Most Significant Digit) Radix Sort:** Sortowanie rozpoczyna się od najbardziej znaczącej cyfry. Może być bardziej efektywny w niektórych przypadkach (np. dla stringów), ale jest bardziej złożony w implementacji, często rekurencyjny.

### Dlaczego Radix Sort?

Radix Sort jest wydajny (często szybszy niż sortowania porównawcze O(n log n)) dla danych spełniających określone warunki, zwłaszcza gdy klucze są liczbami całkowitymi, a ich zakres lub liczba cyfr (k) jest stosunkowo mała. Złożoność czasowa to O(nk), gdzie n to liczba elementów, a k to liczba cyfr (lub bitów) w największej liczbie. Jeśli k jest małe i stałe w stosunku do n, złożoność jest liniowa O(n). Jest to algorytm sortujący nieporównawczo.

### Kto używa?

Algorytm Radix Sort jest używany w sytuacjach, gdzie wydajne sortowanie dużych zbiorów danych całkowitoliczbowych jest kluczowe, np. w systemach baz danych, przetwarzaniu danych, czy specjalistycznych zastosowaniach obliczeniowych. Implementacje dla liczb zmiennoprzecinkowych (jak w tym przykładzie) wymagają konwersji do postaci całkowitoliczbowej.

## Opis Koncepcyjny

Wyobraźmy sobie sortowanie liczb: 170, 45, 75, 90, 802, 24, 2, 66.

1. **Sortowanie wg cyfry jedności:**
   Kubełki:
   0: 17**0**, 9**0**
   1:
   2: 80**2**, **2**
   3:
   4: 2**4**
   5: 4**5**, 7**5**
   6: 6**6**
   7: 170 (już w kubełku 0, ale przykład)
   8:
   9:
   Po zebraniu: 170, 90, 802, 2, 24, 45, 75, 66
2. **Sortowanie wg cyfry dziesiątek:**
   Kubełki:
   0: 8**0**2, **0**2 (teraz 2)
   1: 1**7**0 (już w kubełku 7, ale przykład)
   2: **2**4
   3:
   4: **4**5
   5:
   6: **6**6
   7: 1**7**0, **7**5
   8:
   9: **9**0
   Po zebraniu: 802, 2, 24, 45, 66, 170, 75, 90
   *Uwaga: Powyższe kubełki są uproszczone. Prawidłowo, po kroku 1 mamy kolejność: [170, 90, 802, 2, 24, 45, 75, 66]. Sortując wg dziesiątek, np. 170 trafi do kubełka '7', 90 do '9', 802 do '0', 2 do '0', 24 do '2', 45 do '4', 75 do '7', 66 do '6'. Otrzymamy: [802, 2, 24, 45, 66, 170, 75, 90]. Zauważmy, że liczby z tą samą cyfrą dziesiątek (802 i 2) zachowały względną kolejność (802 przed 2), ponieważ kubełki są przetwarzane w kolejności.
3. **Sortowanie wg cyfry setek:**
   Kubełki:
   0: 2, 24, 45, 66, 170, 75, 90
   1: **1**70 (już w kubełku 0, ale przykład)
   8: **8**02
   ... itd.
   Po zebraniu: 2, 24, 45, 66, 75, 90, 170, 802. Tablica jest posortowana.

## Wizualizacja graficzna

Poniższe grafiki przedstawiają kolejne etapy działania algorytmu Radix Sort (LSD) na przykładowym zbiorze danych.

### Krok 1: Przykładowa tablica

Zakładając przykładową tablicę, przejdźmy wizualnie przez proces sortowania używając Radix LSD bucket sort.
![Pierwszy krok wizualizacji sortowania](1.png "Pierwszy krok wizualizacji sortowania")

### Krok 2: Sortowanie według cyfry jedności

Umieszczenie elementów w kubełkach na podstawie cyfry jedności, a następnie zebranie ich w kolejności.
![Drugi krok wizualizacji sortowania](2.png "Drugi krok wizualizacji sortowania")

### Krok 3: Sortowanie według cyfry dziesiątek

Umieszczenie elementów (już częściowo posortowanych wg jedności) w kubełkach na podstawie cyfry dziesiątek i ponowne zebranie.
![Trzeci krok wizualizacji sortowania](3.png "Trzeci krok wizualizacji sortowania")

### Krok 4: Sortowanie według cyfry setek

Umieszczenie elementów (już częściowo posortowanych wg jedności i dziesiątek) w kubełkach na podstawie cyfry setek i ponowne zebranie.
![Czwarty krok wizualizacji sortowania](4.png "Czwarty krok wizualizacji sortowania")

### Krok 5: Posortowany zbiór

Po przetworzeniu wszystkich znaczących cyfr, zbiór danych jest w pełni posortowany.
![Ostatni krok wizualizacji sortowania](5.png "Ostatni krok wizualizacji sortowania")

## Opis implementacji

### Podział kodu i realizacja

Implementacja Radix Sort dla liczb zmiennoprzecinkowych (double) została zrealizowana w dwóch językach: C++ i Python.
W obu przypadkach kod jest podzielony na dwie główne funkcje sortujące:

1. Funkcja sortująca liczby **całkowite** (przyjmująca liczby nieujemne w Pythonie i C++ z pewną tolerancją, jak niżej). Jest to rdzeń algorytmu Radix Sort LSD bazujący na kubełkach.
   * C++: `void radixSortInt(std::vector<long long>& arr)` - sortuje bezpośrednio podany wektor.
   * Python: `def radix_lsd_bucket_sort(arr)` - zwraca posortowaną listę.
2. Funkcja sortująca liczby **zmiennoprzecinkowe** (`double` w C++, `float` w Pythonie, ale testowane na `double`/liczbach zmiennoprzecinkowych o większej precyzji). Ta funkcja:
   * Oddziela liczby ujemne od nieujemnych.
   * Skaluje liczby zmiennoprzecinkowe do postaci całkowitoliczbowej poprzez pomnożenie przez $10^{\text{precision}}$ (gdzie `precision` to zadana precyzja sortowania).
   * Liczby ujemne są dodatkowo traktowane ich wartością bezwzględną przed konwersją i sortowaniem.
   * Wywołuje funkcję sortującą liczby całkowite na tak przygotowanych danych.
   * Konwertuje posortowane liczby całkowite z powrotem na liczby zmiennoprzecinkowe, dzieląc przez ten sam współczynnik skalujący.
   * Odwraca kolejność posortowanych liczb ujemnych (ponieważ były sortowane według wartości bezwzględnej rosnąco, a chcemy je mieć malejąco).
   * Łączy posortowane liczby ujemne i nieujemne w jedną posortowaną tablicę/listę (ujemne przed nieujemnymi).
   * C++: `std::vector<double> radixSortFloats(const std::vector<double>& arr, const int precision = 6)` - zwraca nową posortowaną tablicę.
   * Python: `def radix_sort_floats(arr, precision=6)` - zwraca nową posortowaną listę.

Oba pliki zawierają również funkcję `main` (lub `if __name__ == '__main__': main()` w Pythonie) demonstrującą użycie algorytmu, generując losowe dane, mierząc czas sortowania Radix Sort i porównując go z natywnym sortowaniem ( `std::ranges::sort` w C++, `sorted()` w Pythonie).

### Struktury danych i nazwy

* **C++:**
  * Główną strukturą danych jest `std::vector<long long>` dla liczb całkowitych i `std::vector<double>` dla liczb zmiennoprzecinkowych. `std::vector` to dynamiczna tablica.
  * Wewnątrz `radixSortInt`, do implementacji kubełków używana jest struktura `std::vector<std::vector<long long>> buckets(10)`. Jest to wektor zawierający 10 wektorów, gdzie każdy wewnętrzny wektor reprezentuje kubełek dla cyfry 0-9.
  * Nazwy zmiennych są opisowe: `arr` (tablica/wektor), `maxVal` (maksymalna wartość), `exp` (aktualny wykładnik potęgi 10, odpowiadający pozycji cyfry), `buckets` (kubełki), `num` (aktualna liczba), `digit` (aktualnie rozpatrywana cyfra), `index` (indeks do wpisywania do posortowanej tablicy).
* **Python:**
  * Główną strukturą danych jest wbudowana `list`. Listy w Pythonie są dynamicznymi tablicami, bardzo elastycznymi.
  * Wewnątrz `radix_lsd_bucket_sort`, kubełki są zaimplementowane jako lista list: `buckets = [[] for _ in range(10)]`.
  * Nazwy zmiennych są zgodne z konwencją Pythona (snake_case): `arr`, `max_val`, `exp`, `buckets`, `number`, `digit`.

## Docstrings dla funkcji w Pythonie

Dla funkcji w kodzie Python (`radix_lsd_bucket_sort` i `radix_sort_floats`) można zastosować różne konwencje docstringów, np. Google Style, NumPy Style, reST style. W tym przypadku zastosowany został **prosty, zwięzły format docstringu**, opisujący cel funkcji, argumenty i zwracaną wartość.

Przykład docstringu dla `radix_lsd_bucket_sort`:

```python
def radix_lsd_bucket_sort(arr):
    """Sorts a list of non-negative integers using LSD Radix Sort with buckets.

    Args:
        arr: A list of non-negative integers to be sorted.

    Returns:
        A new list containing the sorted integers.
        Returns an empty list if the input list is empty.
    """
    # ... implementation ...
    pass # example
```

Przykład docstringu dla `radix_sort_floats`:

```python
def radix_sort_floats(arr, precision=6):
    """Sorts a list of floating-point numbers using Radix Sort.

    Handles both positive and negative numbers by converting them to integers
    based on the specified precision, sorting, and converting back.

    Args:
        arr: A list of floating-point numbers (doubles) to be sorted.
        precision: The number of decimal places to consider for sorting.
                   Defaults to 6. Higher precision increases the number
                   of digits/iterations (k) for the integer sort.

    Returns:
        A new list containing the sorted floating-point numbers.
        Returns an empty list if the input list is empty.
    """
    # ... implementation ...
    pass # example
```

## Opis i różnice między strukturami danych w C++ i Pythonie

### C++ `std::vector` vs. Python `list`

| Cecha                             | `std::vector` w C++                                                                                                                                           | `list` w Pythonie                                                                                                                                                                  |
| :-------------------------------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Typ elementów**          | Statycznie typowany (przechowuje elementy jednego typu określonego przy deklaracji, np.`long long`, `double`).                                             | Dynamicznie typowany (może przechowywać elementy różnych typów, choć często używany homogenicznie).                                                                          |
| **Zarządzanie pamięcią** | Automatyczne zarządzanie wewnętrznym buforem (re-alokacja w miarę potrzeb), ale programista zarządza samym obiektem `vector`.                             | W pełni automatyczne zarządzanie pamięcią (garbage collection).                                                                                                                  |
| **Alokacja pamięci**       | Zwykle alokuje pamięć w sposób ciągły (kontiguous), co zapewnia szybki dostęp do elementów po indeksie i dobrą wydajność cache.                       | Może, ale nie musi, alokować pamięć ciągle w zależności od implementacji i zawartości (np. lista obiektów może przechowywać wskaźniki). Dostęp po indeksie jest szybki. |
| **Rozmiar**                 | Dynamiczny, można zmieniać rozmiar po utworzeniu.                                                                                                             | Dynamiczny, można zmieniać rozmiar po utworzeniu, bardzo elastyczny.                                                                                                               |
| **Wydajność**             | Zazwyczaj wyższa wydajność dla operacji wymagających szybkiego dostępu do pamięci i obliczeń na jednolitych danych, mniejszy narzut pamięci na element. | Większy narzut pamięci na element (przechowuje typ i inne metadane), operacje często mają większy stały koszt, ale duża elastyczność i wygoda użycia.                      |
| **Słownia i składnia**    | Wymaga deklaracji typu, dostęp przez `[]` lub `.at()`, metody takie jak `.push_back()`, `.size()`.                                                     | Nie wymaga deklaracji typu, dostęp przez `[]`, metody takie jak `.append()`, `.extend()`, `len()`.                                                                          |

### Kubełki (`std::vector<std::vector<long long>>` vs. `list[list[int]]`)

W obu językach kubełki są zaimplementowane jako "lista list" lub "wektor wektorów". Koncepcyjnie działają tak samo: zewnętrzna struktura ma 10 elementów (po jednym dla każdej cyfry 0-9), a każdy element wewnętrzny to dynamiczna tablica/lista przechowująca liczby, które mają daną cyfrę na aktualnie sortowanej pozycji.

Różnice wynikają z podstawowych różnic między `std::vector` a `list`:

* W C++ kubełki przechowują `std::vector<long long>`, co oznacza, że każdy kubełek to wektor liczb całkowitych.
* W Pythonie kubełki przechowują `list[int]`, co oznacza, że każdy kubełek to lista liczb całkowitych.

Zarządzanie pamięcią, typowanie i ogólna wydajność poszczególnych kubełków (wewnętrznych wektorów/list) oraz zewnętrznej struktury (wektora/listy kubełków) podlegają tym samym różnicom, co opisano powyżej dla `std::vector` i `list`. Implementacja w C++ jest bardziej niskopoziomowa i wymaga jawnego określenia typów, podczas gdy implementacja w Pythonie jest bardziej abstrakcyjna i opiera się na dynamicznym typowaniu i automatycznym zarządzaniu pamięcią.